
package audio;

/**
 *
 * @author samuel
 */
public abstract class ProgressListener {
    public abstract void update(double percentage);
}
